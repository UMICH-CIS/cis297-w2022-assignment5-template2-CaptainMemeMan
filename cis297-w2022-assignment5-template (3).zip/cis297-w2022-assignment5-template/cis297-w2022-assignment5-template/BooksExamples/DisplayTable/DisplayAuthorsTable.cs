﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 

namespace DisplayTable
{
    public partial class DisplayAuthorsTable : Form
    {
        public DisplayAuthorsTable()
        {
            InitializeComponent();
        }
        
        //Entity Framework DbContext
        private BooksExamples.BooksEntities dbcontext = new BooksExamples.BooksEntities();
        //load data from database into DataGridView
        private void DisplayAuthorsTable_Load(object sender, EventArgs e)
        {
            //load Authors table ordered by LastName then FirstName
            dbcontext.Authors
                .OrderBy(author => author.LastName)
                .ThenBy(author => author.FirstName)
                .Load();
            //specify datasource for authorBindingSource
            
            authorBindingSource.DataSource = dbcontext.Authors.Local;

        }
        private void authorBindingNavigator_RefreshItems(object sender, EventArgs e)
        {
            //load Authors table ordered by LastName then FirstName
            dbcontext.Authors
                .OrderBy(author => author.LastName)
                .ThenBy(author => author.FirstName)
                .Load();
            //specify datasource for authorBindingSource
            authorBindingSource.DataSource = dbcontext.Authors.Local;
        }

        
        private void authorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            Validate();
            authorBindingSource.EndEdit();
            try
            {
                dbcontext.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException)
            {
                MessageBox.Show("FirstName and LastName must contain values", "Entity Validation Exception");
            }
        }

        private void authorDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var lastNameQuery = dbcontext.Authors;
            authorBindingSource.DataSource = lastNameQuery.ToList();
            authorBindingSource.MoveFirst();
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorDeleteItem.Enabled = false; 
        }

        private void restFormToolStripMenuItem_Click(object sender, EventArgs e) //this would reset the data base 
        {
            if (dbcontext != null)
            {
                dbcontext.Dispose(); 
            }
            dbcontext = new BooksExamples.BooksEntities();
            dbcontext.Authors.ToList();
            authorDataGridView.DataSource = dbcontext.Authors.Local;
            authorBindingSource.MoveFirst();
            LastNameTextBox.Clear(); 
            
        }

        private void BookTitleTextBox_TextChanged(object sender, EventArgs e)
        { 
            var lastNameQuery = from author in dbcontext.Authors where author.LastName.StartsWith(LastNameTextBox.Text) orderby author.LastName, author.FirstName select author;
            authorDataGridView.DataSource = lastNameQuery.ToList();
            authorBindingSource.MoveFirst();
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorDeleteItem.Enabled = false;

        }

        private void DisplayAuthorsTable_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'booksDataSet.AuthorISBN' table. You can move, or remove it, as needed.
            this.authorISBNTableAdapter.Fill(this.booksDataSet.AuthorISBN);
            // TODO: This line of code loads data into the 'booksDataSet.Titles' table. You can move, or remove it, as needed.
            this.titlesTableAdapter.Fill(this.booksDataSet.Titles);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void resetDataTable2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dbcontext != null)
            {
                dbcontext.Dispose();
            }
            dbcontext = new BooksExamples.BooksEntities();
            dbcontext.Titles.ToList();
            titlesBindingSource.DataSource = dbcontext.Titles.Local;
            titlesBindingSource.MoveFirst();
            BookTitleTextBox.Clear(); 
        }

        private void BookTitleTextBox_TextChanged_1(object sender, EventArgs e)
        {
            var TitleString = from title in dbcontext.Titles where title.Title1.StartsWith(BookTitleTextBox.Text) orderby title.Title1, title.ISBN, title.EditionNumber, title.Copyright select title;
            titlesBindingSource.DataSource = TitleString.ToList();
            titlesBindingSource.MoveFirst();
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorDeleteItem.Enabled = false;
        }


        private void titleGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           // dbcontext.Titles.OrderBy(title => title.Title1).ThenBy(title => title.EditionNumber).ThenBy(title => title.Copyright).Load();
        }

        private void AuthorIDSearchTextBox_TextChanged(object sender, EventArgs e)
        {
            var titlesAndAuthors1 = from title in dbcontext.Titles
                                    from author in title.Authors
                                    orderby title.Title1, author.LastName, author.FirstName
                                    select
            new { title.Title1, author.FirstName, author.LastName };
            authorDataGridView.DataSource = titlesAndAuthors1.ToList();
            titlesBindingSource.DataSource = titlesAndAuthors1.ToList();
            authorBindingSource.MoveFirst();
            titlesBindingSource.MoveFirst(); 
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorDeleteItem.Enabled = false;

        }

        private void resetDataTable3ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}


